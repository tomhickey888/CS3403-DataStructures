#include "queueArray.h"; 


void processOption(int option)
{
	static bool flag = false;
	int num = 10; 
	switch (option)
	{
	case 1:
			createQueue();
			printf("creating a queue ....\n");
			flag = true;
		
		break;

	

	case 2: //enqueue: you can't enqueue unless you have created a queue 
		if (!flag)
		{
			printf("You need to create a queue first ....\n");
			createQueue();
			
			flag = true;
		}
		//generateRandom(num); //input form keyboard, file, or generate random 
		enqueue(num); 
		break;
	case 3: 
		dequeue(num); 
		printf("The number %d was removed from the queue", num); 
		break;

	}//switch

}//method 
void main()
{
	int option = 0;
	do
	{
		printf("Enter an option to begin:\n");
		printf("1: Create a new queue\n");
		printf("2. Add an element to the queue (enqueue) \n");
		printf("3. Remove an element from the queue (dequeue) \n");
		printf("4. Display and remove all queue elements (process the queue)\n");
		printf("5. Exit \n\n");
		cin >> option;
		processOption(option);
	}
	while (option != 5); 


	
}