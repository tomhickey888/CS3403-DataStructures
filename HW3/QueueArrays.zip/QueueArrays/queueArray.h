#pragma once
#include<iostream>
#include<ctime>
using namespace std;
int queueSize=0;
int * queueArray; 
int front; 
int rear; 
int numElements = 0 ;

bool isFull()
{
	bool status = true;
	if (numElements<queueSize)// if  (numElements != 0)
		status = false;
	else
		status = true;

	return status;

}

int generateRandoms()
{
	srand(time(NULL));

	
		int num = std::rand() % 100 + 1;
		return num; 
	
}

void enqueue(int num)
{
	if (isFull())
		printf("The queue is full, you can't add more to the queue!");
	else
	{
		// method is full 
		//rear++; // linear queue 
		//circular queue
		rear = (rear + 1) % queueSize;
		num = generateRandoms();
		queueArray[rear] = num;

		printf("The number %d was added to the queue...", num);
		numElements++;

	}
	
}

bool isEmpty()
{
	bool status= true; 
	if (numElements)// if  (numElements != 0)
		status = false;
	else
		status = true; 

	return status; 

}

void dequeue(int &num)// no need for return value .. 
// pass by reference  
//num dequeue ()  to pass by value then you a return statement return num; 
{
	if (isEmpty())
		printf("The queue is empty, you can't dequeue yet!");
	else
	{
		front = (front + 1) % queueSize; // cicurlar queue 
		num = queueArray[front]; 
		numElements--; 

	} 

}

void createQueue()
{
	//dyamically allocated array 
	printf("Enter queue size: ");
	cin >> queueSize; 
	//dyanmically allocate memory to the array being used for the queue 
	queueArray = new int[queueSize];


}