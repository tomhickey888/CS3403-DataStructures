#pragma once

struct freq
{
	char alpha;
	int freq;
};