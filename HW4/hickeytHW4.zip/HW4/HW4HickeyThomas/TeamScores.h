#pragma once
#include<string>

using namespace std;

struct TeamScores
{
	string team1;
	string team2;
	int score1;
	int score2;
};
